﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Windows.Forms.DataVisualization;
using System.Windows.Forms.DataVisualization.Charting;

namespace ThreadCheck
{
    public partial class MainForm : Form
    {
        HttpSpeedTestThread mngth = null;

        Chart chrtResult1 = null;
        Chart chrtResult2 = null;
        Chart chrtResult3 = null;
        Chart chrtResult4 = null;
        Series series1 =null;
        Series series2 = null;
        Series series3 = null;
        Series series4 = null;

        double TotalSpeed = 0;
        double MaxSpeed = 0;
        double MinSpeed = 0;
        double AvgSpeed = 0;

        double TotalSec = 0;
        double MaxSec = 0;
        double MinSec = 0;
        double AvgSec= 0;

        double TotalBit = 0;
        double MaxBit = 0;
        double MinBit = 0;
        double AvgBit = 0;

        int count = 0;

        public MainForm()
        {
            InitializeComponent();

            InitParam();

            InitializeChart();
        }

        private void InitParam()
        {
            this.txtUrl.Text = "http://www.google.co.jp";
            this.txtMax.Text = "";
            this.txtMin.Text = "";
            this.txtAve.Text = "";
            this.rdAuto.Checked = true;
            this.rdManu.Checked = false;
            this.ndCnt.Value = 3;
            this.ndCnt.Enabled = false;
            this.ndInt.Value = 1;
            this.ndInt.Enabled = false;
            this.rdMin.Checked = false;
            this.rdSec.Checked = true;
            this.rdSec.Enabled = true;

            this.dataGridView1.Anchor = new System.Windows.Forms.AnchorStyles();
            this.dataGridView1.Columns["Mbps"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dataGridView1.Columns["Bps"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            this.dataGridView2.Anchor = new System.Windows.Forms.AnchorStyles();
            this.dataGridView2.Columns["exectime"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dataGridView2.Columns["data"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            
            this.txtMsg.Text = "お好みの設定をしてStartボタンを押すと測定が始まります･･･";
        }


        private void InitializeChart()
        {
            comboBox.Items.Add(SeriesChartType.Range);
            comboBox.Items.Add(SeriesChartType.Line);
            comboBox.SelectedItem = SeriesChartType.Line;

            // グラフ１ (Mbps)
            chrtResult1 = new Chart();
            ChartArea chartArea1 = new ChartArea();
            this.chrtResult1.ChartAreas.Add(chartArea1);
            this.chrtResult1.Location = new System.Drawing.Point(265, 210);
            this.chrtResult1.Size = new System.Drawing.Size(350, 200);
            this.chrtResult1.Visible = true;
            this.Controls.AddRange(new System.Windows.Forms.Control[] { this.chrtResult1 });

            // グラフ２ (Sec)
            chrtResult2 = new Chart();
            ChartArea chartArea2 = new ChartArea();
            this.chrtResult2.ChartAreas.Add(chartArea2);
            this.chrtResult2.Location = new System.Drawing.Point(640, 210);
            this.chrtResult2.Size = new System.Drawing.Size(350, 200);
            this.chrtResult2.Visible = true;
            this.Controls.AddRange(new System.Windows.Forms.Control[] { this.chrtResult2 });

            // グラフ３ (bps)
            chrtResult3 = new Chart();
            ChartArea chartArea3 = new ChartArea();
            this.chrtResult3.ChartAreas.Add(chartArea3);
            this.chrtResult3.Location = new System.Drawing.Point(265, 450);
            this.chrtResult3.Size = new System.Drawing.Size(350, 200);
            this.chrtResult3.Visible = true;
            this.Controls.AddRange(new System.Windows.Forms.Control[] { this.chrtResult3 });

            // グラフ４ (bit)
            chrtResult4 = new Chart();
            ChartArea chartArea4 = new ChartArea();
            this.chrtResult4.ChartAreas.Add(chartArea4);
            this.chrtResult4.Location = new System.Drawing.Point(640, 450);
            this.chrtResult4.Size = new System.Drawing.Size(350, 200);
            this.chrtResult4.Visible = true;
            this.Controls.AddRange(new System.Windows.Forms.Control[] { this.chrtResult4 });
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            clearParameters();
            
            string url = this.txtUrl.Text;
            if (!urlCheck(url))
            {
                MessageBox.Show("正しいURLを指定してください");
                enableControl(1);
                return;
            }

            enableControl(0);

            int cnt = int.Parse(this.ndCnt.Value.ToString());
            if (cnt == 0)
            {
                MessageBox.Show("1 以上の回数を指定してください");
                enableControl(1);
                return;
            }

            int val = int.Parse(this.ndInt.Value.ToString());
            if (val == 0)
            {
                MessageBox.Show("1 以上の時間を指定してください");
                enableControl(1);
                return;
            }

            bool blsec = false;
            if (this.rdSec.Checked == true)
            {
                blsec = true;
            }
            else
            {
                blsec = false;
            }

            this.btnClose.Enabled = false;

            this.txtMsg.Text = "測定を開始しました。データ取得までしばらくお待ちください･･･";

            Thread t = null;
            mngth = new HttpSpeedTestThread(this, cnt, val, blsec, url);
            mngth.mngEvent += new HttpSpeedTestThread.MngThreadEventHandler(this.FormUpdate);
            mngth.mngCallBack += new HttpSpeedTestThread.MngThreadCallback(this.execCallback);

            t = new Thread(new ThreadStart(mngth.exec));

            t.Start();

        }

        public void FormUpdate(string txtDate, double data, double execTime, double bit)
        {
            this.count++;
            
            this.txtMsg.Text = "測定中です" + "･･･" + count.ToString() + "回め";
            this.txtMsg.Update();

            double mbps = data / 1000 / 1000;
            this.TotalSpeed += mbps;
            this.AvgSpeed = TotalSpeed / count;

            if (this.count == 1)
            {
                this.MaxSpeed = mbps;
            }
            else if (this.MaxSpeed < mbps)
            {
                this.MaxSpeed = mbps;
            }

            if (this.count == 1)
            {
                this.MinSpeed = mbps;
            }
            else if (this.MinSpeed > mbps)
            {
                this.MinSpeed = mbps;
            }

            string bps = ToHalfAdjust(data, 2).ToString();
            string strMbps = ToHalfAdjust(mbps, 2).ToString();

            this.txtMax.Text = ToHalfAdjust(MaxSpeed,2).ToString();
            this.txtMin.Text = ToHalfAdjust(MinSpeed,2).ToString();
            this.txtAve.Text = ToHalfAdjust(AvgSpeed,2).ToString();
            this.txtMax.Update();
            this.txtMin.Update();
            this.txtAve.Update();

            this.TotalSec += execTime;
            this.AvgSec = TotalSec / count;
            if (this.count == 1)
            {
                this.TotalSec = execTime;
            }
            else if (this.MaxSec < execTime)
            {
                this.MaxSec = execTime;
            }

            if (this.count == 1)
            {
                this.MinSec = execTime;
            }
            else if (this.MinSec > execTime)
            {
                this.MinSec = execTime;
            }
            this.txtMaxSec.Text = ToHalfAdjust(MaxSec, 2).ToString();
            this.txtMinSec.Text = ToHalfAdjust(MinSec, 2).ToString();
            this.txtAvSec.Text = ToHalfAdjust(AvgSec, 2).ToString();
            this.txtMaxSec.Update();
            this.txtMinSec.Update();
            this.txtAvSec.Update();



            this.TotalBit += bit;
            this.AvgBit = TotalBit / count;
            if (this.count == 1)
            {
                this.TotalBit = bit;
            }
            else if (this.MaxBit < execTime)
            {
                this.MaxBit = bit;
            }

            if (this.count == 1)
            {
                this.MinBit = bit;
            }
            else if (this.MinBit > bit)
            {
                this.MinBit = bit;
            }
            this.txtMaxData.Text = ToHalfAdjust(MaxBit, 2).ToString();
            this.txtMinData.Text = ToHalfAdjust(MinBit, 2).ToString();
            this.txtAvgData.Text = ToHalfAdjust(AvgBit, 2).ToString();
            this.txtMaxData.Update();
            this.txtMinData.Update();
            this.txtAvgData.Update();

            try
            {
                string[] row = new string[] { txtDate, strMbps, bps };
                this.dataGridView1.Rows.Add(row);

                foreach (DataGridViewColumn c in dataGridView1.Columns)
                    c.SortMode = DataGridViewColumnSortMode.Programmatic;

                DataGridViewColumn sortColumn = dataGridView1.CurrentCell.OwningColumn;
                ListSortDirection sortDirection = ListSortDirection.Ascending;

                dataGridView1.Sort(sortColumn, sortDirection);
                dataGridView1.FirstDisplayedScrollingRowIndex = dataGridView1.Rows.Count - 1;
                this.dataGridView1.Update();


                string[] row2 = new string[] { txtDate, execTime.ToString(), bit.ToString() };
                this.dataGridView2.Rows.Add(row2);

                foreach (DataGridViewColumn d in dataGridView2.Columns)
                    d.SortMode = DataGridViewColumnSortMode.Programmatic;

                DataGridViewColumn sortColumn2 = dataGridView2.CurrentCell.OwningColumn;
                ListSortDirection sortDirection2 = ListSortDirection.Ascending;

                dataGridView2.Sort(sortColumn2, sortDirection2);
                dataGridView2.FirstDisplayedScrollingRowIndex = dataGridView2.Rows.Count - 1;
                this.dataGridView2.Update();


                if (this.series1 != null)
                {
                    this.series1.Dispose();
                }
                this.series1 = new Series();

                this.chrtResult1.ChartAreas[0].Area3DStyle.Enable3D = checkBox1.Checked;
                this.series1.ChartType = (SeriesChartType)comboBox.SelectedItem;

                DataPoint point;
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    point = series1.Points.Add(Convert.ToDouble(dataGridView1.Rows[i].Cells[1].Value));
                    point.AxisLabel = dataGridView1.Rows[i].Cells[0].Value.ToString();
                }

                this.chrtResult1.Series.Clear();
                this.chrtResult1.Series.Add(series1);
                this.chrtResult1.ResetAutoValues();
                this.chrtResult1.Update();

                if (this.series2 != null)
                {
                    this.series2.Dispose();
                }
                this.series2 = new Series();

                this.chrtResult2.ChartAreas[0].Area3DStyle.Enable3D = checkBox1.Checked;
                this.series2.ChartType = (SeriesChartType)comboBox.SelectedItem;

                DataPoint point2;
                for (int j = 0; j < dataGridView2.Rows.Count - 1; j++)
                {
                    point2 = series2.Points.Add(Convert.ToDouble(dataGridView2.Rows[j].Cells[1].Value));
                    point2.AxisLabel = dataGridView2.Rows[j].Cells[0].Value.ToString();
                }

                this.chrtResult2.Series.Clear();
                this.chrtResult2.Series.Add(series2);
                this.chrtResult2.ResetAutoValues();
                this.chrtResult2.Update();

                if (this.series3 != null)
                {
                    this.series3.Dispose();
                }
                this.series3 = new Series();

                this.chrtResult3.ChartAreas[0].Area3DStyle.Enable3D = checkBox1.Checked;
                this.series3.ChartType = (SeriesChartType)comboBox.SelectedItem;

                DataPoint point3;
                for (int k = 0; k < dataGridView1.Rows.Count - 1; k++)
                {
                    point3 = series3.Points.Add(Convert.ToDouble(dataGridView1.Rows[k].Cells[2].Value));
                    point3.AxisLabel = dataGridView2.Rows[k].Cells[0].Value.ToString();
                }

                this.chrtResult3.Series.Clear();
                this.chrtResult3.Series.Add(series3);
                this.chrtResult3.ResetAutoValues();
                this.chrtResult3.Update();

                if (this.series4 != null)
                {
                    this.series4.Dispose();
                }
                this.series4 = new Series();

                this.chrtResult4.ChartAreas[0].Area3DStyle.Enable3D = checkBox1.Checked;
                this.series4.ChartType = (SeriesChartType)comboBox.SelectedItem;

                DataPoint point4;
                for (int m = 0; m < dataGridView2.Rows.Count - 1; m++)
                {
                    point4 = series4.Points.Add(Convert.ToDouble(dataGridView2.Rows[m].Cells[2].Value));
                    point4.AxisLabel = dataGridView2.Rows[m].Cells[0].Value.ToString();
                }

                this.chrtResult4.Series.Clear();
                this.chrtResult4.Series.Add(series4);
                this.chrtResult4.ResetAutoValues();
                this.chrtResult4.Update();

            }
            catch (Exception ex)
            {
            }
        }

        private void execCallback(int ret)
        {
            if (ret == 0)
            {
                this.txtMsg.Text = "測定が終わりました";
            }
            else if(ret == 1)
            {
                this.txtMsg.Text = "測定を中止しました";
            }
            else if (ret == 2)
            {
                this.txtMsg.Text = "測定が異常終了しました";
            }

            this.txtMsg.Update();

            mngth.mngEvent -= new HttpSpeedTestThread.MngThreadEventHandler(this.FormUpdate);
            mngth.mngCallBack -= new HttpSpeedTestThread.MngThreadCallback(this.execCallback);

            this.count = 0;

            this.TotalSpeed = 0;
            this.MaxSpeed = 0;
            this.MinSpeed = 0;
            this.AvgSpeed = 0;
            this.TotalSec = 0;
            this.MaxSec = 0;
            this.MinSec = 0;
            this.AvgSec = 0;
            this.TotalBit = 0;
            this.MaxBit = 0;
            this.MinBit = 0;
            this.AvgBit = 0;

            enableControl(1);

            System.Threading.Thread.Sleep(2000);
            this.txtMsg.Text = "お好みの設定をしてStartボタンを押すと測定が始まります･･･";
        }

        private void clearParameters()
        {
            this.dataGridView1.Rows.Clear();
            this.dataGridView2.Rows.Clear();

            if (this.series1 != null)
            {
                this.series1.Dispose();
            }
            this.count = 0;
            this.TotalSpeed = 0;
            this.MaxSpeed = 0;
            this.MinSpeed = 0;
            this.AvgSpeed = 0;
            this.TotalSec = 0;
            this.MaxSec = 0;
            this.MinSec = 0;
            this.AvgSec = 0;
            this.TotalBit = 0;
            this.MaxBit = 0;
            this.MinBit = 0;
            this.AvgBit = 0;
            this.txtMax.Clear();
            this.txtMin.Clear();
            this.txtAve.Clear();
            this.txtMaxSec.Clear();
            this.txtMinSec.Clear();
            this.txtAvSec.Clear();
            this.txtMaxData.Clear();
            this.txtMinData.Clear();
            this.txtAvgData.Clear();

            if (this.rdManu.Checked == true)
            {
                this.rdMin.Enabled = true;
            }

        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            this.txtMsg.Text = "";
            this.txtMsg.Text = "測定を中止しました";
            this.txtMsg.Update();

            mngth.stop();
            enableControl(1);
            this.count = 0;
            this.TotalSpeed = 0;
            this.MaxSpeed = 0;
            this.MinSpeed = 0;
            this.AvgSpeed = 0;

            System.Threading.Thread.Sleep(2000);
            this.txtMsg.Text = "お好みの設定をしてStartボタンを押すと測定が始まります･･･";
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private bool urlCheck(string url)
        {
            bool blRet = false;

            System.Text.RegularExpressions.Regex regex =
              new System.Text.RegularExpressions.Regex(@"http(s)?://([\w-]+\.)+[\w-]+(/[\w- ./?%&=]*)?");
            System.Text.RegularExpressions.Match m =
                regex.Match(url);
            if (m.Success)
            {
                blRet = true;
            }
            else
            {
                blRet = false;
            }

            return blRet;
        }

        private void enableControl(int ptn)
        {
            switch (ptn)
            {
                case 0:
                    if (this.rdManu.Checked == true)
                    {
                        this.rdAuto.Enabled = false;
                    }
                    else
                    {
                        this.rdManu.Enabled = false;
                    }
                    if (this.rdMin.Checked == true)
                    {
                        this.rdSec.Enabled = false;
                    }
                    else
                    {
                        this.rdMin.Enabled = false;
                    }
                    this.btnClose.Enabled = false;
                    this.btnStart.Enabled = false;
                    this.btnStop.Enabled = true;
                    this.ndCnt.Enabled = false;
                    this.ndInt.Enabled = false;
                    break;
                case 1:
                    this.btnClose.Enabled = true;
                    this.btnStart.Enabled = true;
                    this.btnStop.Enabled = false;
                    if (this.rdManu.Checked == true)
                    {
                        this.rdAuto.Enabled = true;
                        this.rdMin.Enabled = true;
                        this.rdSec.Enabled = true;
                        this.ndCnt.Enabled = true;
                        this.ndInt.Enabled = true;
                    }
                    else
                    {
                        this.rdManu.Enabled = true;
                        this.rdMin.Enabled = false;
                        this.rdSec.Enabled = true;
                        this.ndCnt.Enabled = false;
                        this.ndInt.Enabled = false;
                    }
                    break;
                default :
                    break;
            }
        }

        private void rdManu_CheckedChanged(object sender, EventArgs e)
        {
            this.ndCnt.Enabled = true;
            this.ndInt.Value = 1;
            this.rdAuto.Enabled = true;
            this.rdMin.Enabled = true;
            this.rdSec.Enabled = true;
            this.ndCnt.Enabled = true;
            this.ndInt.Enabled = true;
        }

        private void rdAuto_CheckedChanged(object sender, EventArgs e)
        {
            this.ndCnt.Value = 3;
            this.ndInt.Value = 1;
            this.rdAuto.Enabled = true;
            this.rdMin.Enabled = false;
            this.rdSec.Checked = true;
            this.rdSec.Enabled = true;
            this.ndCnt.Enabled = false;
            this.ndInt.Enabled = false;
        }

        public static double ToHalfAdjust(double dValue, int iDigits)
        {
            double dCoef = System.Math.Pow(10, iDigits);

            return dValue > 0 ? System.Math.Floor((dValue * dCoef) + 0.5) / dCoef :
                            System.Math.Ceiling((dValue * dCoef) - 0.5) / dCoef;
        }
    }
}
