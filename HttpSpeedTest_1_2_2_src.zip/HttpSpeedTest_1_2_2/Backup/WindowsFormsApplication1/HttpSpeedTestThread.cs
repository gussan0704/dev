﻿//#define TEST_1

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Net;

namespace ThreadCheck
{
    class HttpSpeedTestThread
    {
        public delegate void MngThreadEventHandler(string txt1, double data, double execTime, double bit);
        public event MngThreadEventHandler mngEvent = null;

        public delegate void MngThreadCallback(int ret);
        public event MngThreadCallback mngCallBack = null;

        System.Windows.Forms.Control cntrl;

        public int count;
        public int interval;
        string targetURL;
        
        bool stopFlg;
        bool blSecFlg;
        double bit;
        double execTime;
        double bps;

        public HttpSpeedTestThread(System.Windows.Forms.Control mainThreadForm,int cnt,int ival,bool blSec ,string url)
        {
            cntrl = mainThreadForm;
            count = cnt;
            interval = ival;
            stopFlg = false;
            blSecFlg = blSec;
            targetURL = url;
        }

        public void stop()
        {
            stopFlg = true;
        }

        public void exec()
        {
            InitParam();
            HttpSpeed();
        }

        private void InitParam()
        {
            if (blSecFlg == true)
            {
                interval = interval * 1000;
            }
            else
            {
                interval = interval * 1000 * 60;
            }
        }

        private void HttpSpeed()
        {
            int cnt = 0;
            try
            {
                while (true)
                {
                    if (cnt >= count || stopFlg == true)
                    {
                        int r = 0;
                        if (stopFlg == true)
                        {
                            r = 1;
                        }
                        cntrl.Invoke(mngCallBack, new object[1] { r });
                        return;
                    }

                    DateTime dtNow = DateTime.Now;

                    GetHttpSpeed();

                    cntrl.Invoke(mngEvent, new object[4] { dtNow.ToString("hh:mm:ss"), bps, execTime, bit });

                    System.Threading.Thread.Sleep(interval);
                    cnt++;

                }
            }
            catch (Exception ex)
            {
                cntrl.Invoke(mngCallBack, new object[1] { 2 });
            }
            finally
            {
                
            }
        }

        private void GetHttpSpeed()
        {
            bit = 0;
            execTime = 0;
            bps = 0;
            byte[] data;
            var watch = new Stopwatch();

            System.Net.HttpWebRequest webreq =
                (System.Net.HttpWebRequest)System.Net.WebRequest.Create(targetURL);
            System.Net.HttpWebResponse webres =
                (System.Net.HttpWebResponse) webreq.GetResponse();
            System.Text.Encoding enc =
                System.Text.Encoding.GetEncoding("utf-8");

            watch.Start();

            System.IO.Stream st = webres.GetResponseStream();
            System.IO.StreamReader sr = new System.IO.StreamReader(st, enc);
            string res = sr.ReadToEnd();
            
            watch.Stop();

            data = Encoding.Unicode.GetBytes(res);

            sr.Close();

            var time = watch.Elapsed;
            execTime = time.TotalSeconds;

            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < data.Length; i++)
            {
                byte b = data[i];
                for (int j = 0; j < 8; j++)
                {
                    sb.Append(b & 0x80);
                    b <<= 1;
                }
            }

            bit = sb.Length;

            if (bit != 0 && execTime != 0)
            {
                bps = bit / execTime;
            }
            else
            {
                bps = 0;
            }
        }
    }
}
