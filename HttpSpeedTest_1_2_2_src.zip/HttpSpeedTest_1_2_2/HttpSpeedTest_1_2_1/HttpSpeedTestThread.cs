﻿//#define TEST_1

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Net;

namespace ThreadCheck
{
    class HttpSpeedTestThread
    {
        public delegate void MngThreadEventHandler(string txt1, double data, double bitsec, double execTime, double bit);
        public event MngThreadEventHandler mngEvent = null;

        public delegate void MngThreadCallback(int ret);
        public event MngThreadCallback mngCallBack = null;

        System.Windows.Forms.Control cntrl;

        public int count;
        public int interval;
        string targetURL;
        
        bool stopFlg;
        bool blSecFlg;
        double bit;
        double execTime;
        double bps;
        double bitsec;

        public HttpSpeedTestThread(System.Windows.Forms.Control mainThreadForm,int cnt,int ival,bool blSec ,string url)
        {
            cntrl = mainThreadForm;
            count = cnt;
            interval = ival;
            stopFlg = false;
            blSecFlg = blSec;
            targetURL = url;
        }

        public void stop()
        {
            stopFlg = true;
        }

        public void exec()
        {
            InitParam();
            HttpSpeed();
        }

        private void InitParam()
        {
            if (blSecFlg == true)
            {
                interval = interval * 1024;
            }
            else
            {
                interval = interval * 1024 * 60;
            }
        }

        private void HttpSpeed()
        {
            int cnt = 0;
            try
            {
                while (true)
                {
                    if (cnt >= count || stopFlg == true)
                    {
                        int r = 0;
                        if (stopFlg == true)
                        {
                            r = 1;
                        }
                        cntrl.Invoke(mngCallBack, new object[1] { r });
                        return;
                    }

                    DateTime dtNow = DateTime.Now;

                    GetHttpSpeed();

                    cntrl.Invoke(mngEvent, new object[5] { dtNow.ToString("hh:mm:ss"), bps,bitsec, execTime, bit });

                    System.Threading.Thread.Sleep(interval);
                    cnt++;

                }
            }
            catch (Exception ex)
            {
                cntrl.Invoke(mngCallBack, new object[1] { 2 });
            }
            finally
            {
                
            }
        }

        private void GetHttpSpeed()
        {
            bit = 0;
            execTime = 0;
            bps = 0;
            bitsec = 0;

            var watch = new Stopwatch();

            System.Text.Encoding enc = System.Text.Encoding.GetEncoding("utf-8");

            System.Net.HttpWebRequest webreq = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(targetURL);
            webreq.ContentType = "application/x-www-form-urlencoded";
            webreq.Proxy = null;

            watch.Start();

            System.Net.HttpWebResponse webres = (System.Net.HttpWebResponse) webreq.GetResponse();

            System.IO.Stream st = webres.GetResponseStream();
            System.IO.StreamReader sr = new System.IO.StreamReader(st, enc);
            bit = enc.GetByteCount(sr.ReadToEnd()) * 8;

            watch.Stop();

            sr.Close();
            st.Close();

            execTime = watch.Elapsed.TotalSeconds;

            if (bit != 0 && execTime != 0)
            {
                bitsec = bit / execTime;
                bps = bit / execTime * 8;
            }
            else
            {
                bps = 0;
            }

            sr = null;
            st = null;
            watch = null;
            GC.Collect();
        }
    }
}
