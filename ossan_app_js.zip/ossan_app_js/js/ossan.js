//------------------------------------------------
// 最大安定傾斜角度の算出プログラム
// copyright© 2018 ossan.mizunarano-mori.info
//------------------------------------------------

//------------------------------------------------
// 重心高の算出
//------------------------------------------------
function onButton1Click() {
  // 入力チェック <HTML側に処理を移動>
/*
  if (isNumber(parseFloat(document.form1.elements[1].value)) == false 
  ||  isNumber(parseFloat(document.form1.elements[2].value)) == false
  ||  isNumber(parseFloat(document.form1.elements[3].value)) == false
  ||  isNumber(parseFloat(document.form1.elements[4].value)) == false
  ||  isNumber(parseFloat(document.form1.elements[5].value)) == false) {
    alert("半角数字以外が含まれています");
    return;
  }
*/
  // フォーム入力項目の取得
  var v_R1 = parseFloat(document.form1.elements[1].value);
  var v_L1 = parseFloat(document.form1.elements[2].value);
  var v_W1 = parseFloat(document.form1.elements[3].value);
  var v_Wr1 = parseFloat(document.form1.elements[4].value);
  var v_h1 = parseFloat(document.form1.elements[5].value);

  // 計算処理
  // L
  target = document.getElementById("id_L2");
  target.value = v_L1;
  // W
  target = document.getElementById("id_W2");
  target.value = v_W1;
  target = document.getElementById("id_w3");
  target.value = v_W1;
  // Wr
  target = document.getElementById("id_Wr2");
  target.value = v_Wr1;
  // cos θ
  var cos_theta = Math.sqrt(Math.pow(v_L1,2) - Math.pow(v_h1,2)) / v_L1;
  target = document.getElementById("id_cos_theta");
  target.value = cos_theta;
  // sin θ
  var sin_theta = v_h1 / v_L1;
  target = document.getElementById("id_sin_theta");
  target.value = sin_theta;
  // Ｗｒ'
  var Wr_dash = (v_Wr1 * cos_theta * cos_theta) + (v_W1 * sin_theta * sin_theta);
  target = document.getElementById("id_Wr_dash");
  target.value = Wr_dash;
  // Ｈ
  var sqrt_content = Math.pow(v_L1, 2) - Math.pow(v_h1, 2);
  var w_diff = Wr_dash - v_Wr1;
  w_diff =  v_L1 * w_diff;
  var devide_wl = w_diff * Math.sqrt(sqrt_content) ;
  var w_h_gross = v_W1 * v_h1;
  var Hight = v_R1 + (devide_wl / w_h_gross);

  target = document.getElementById("id_H");
  target.value = Hight;
  target = document.getElementById("id_H2");
  target.value = Hight;
}
//------------------------------------------------
// 安定幅の計算
//------------------------------------------------
function onButton2Click() {

  // 入力チェック <HTML側に処理を移動>
/*
  if (isNumber(parseFloat(document.form2.elements[1].value)) == false 
  ||  isNumber(parseFloat(document.form2.elements[2].value)) == false
  ||  isNumber(parseFloat(document.form2.elements[3].value)) == false
  ||  isNumber(parseFloat(document.form2.elements[4].value)) == false
  ||  isNumber(parseFloat(document.form2.elements[5].value)) == false
  ||  isNumber(parseFloat(document.form2.elements[6].value)) == false
  ||  isNumber(parseFloat(document.form2.elements[7].value)) == false
  ||  isNumber(parseFloat(document.form2.elements[8].value)) == false
  ||  isNumber(parseFloat(document.form2.elements[9].value)) == false
  ||  isNumber(parseFloat(document.form2.elements[10].value)) == false) {
    alert("数値以外の文字が含まれています");
    return;
  }
*/
  // フォーム入力項目の取得
  var v_Tf2 = parseFloat(document.form2.elements[1].value);
  var v_Tr2 = parseFloat(document.form2.elements[2].value);
  var v_L2 = parseFloat(document.form2.elements[3].value);
  var v_W2 = parseFloat(document.form2.elements[4].value);
  var v_Wf2 = parseFloat(document.form2.elements[5].value);
  var v_Wr2 = parseFloat(document.form2.elements[6].value);
  var v_Wfl2 = parseFloat(document.form2.elements[7].value);
  var v_Wfr2 = parseFloat(document.form2.elements[8].value);
  var v_Wrl2 = parseFloat(document.form2.elements[9].value);
  var v_Wrr2 = parseFloat(document.form2.elements[10].value);

  // 計算処理
  // Bl
  var tan_arfa = (v_Tr2 - v_Tf2) / (2 * v_L2);
  var arfa = Math.atan(tan_arfa) * 180 / Math.PI;
  var cos_arfa = Math.cos(Math.atan(tan_arfa));
  var result_bl = v_Wfr2 * v_Tf2 + v_Wrr2 * v_Tr2;
  result_bl = result_bl * cos_arfa;
  result_bl = result_bl / v_W2;
  target = document.getElementById("id_Bl");
  target.value = result_bl;
  target = document.getElementById("id_Bl2");
  target.value = result_bl;

  // Br
  var result_br = v_Wfl2 * v_Tf2 + v_Wrl2 * v_Tr2;
  result_br = result_br * cos_arfa;
  result_br = result_br / v_W2;
  target = document.getElementById("id_Br");
  target.value = result_br;
  target = document.getElementById("id_Br2");
  target.value = result_br;

}
//------------------------------------------------
// 最大安定傾斜角度の計算
//------------------------------------------------
function onButton3Click() {

  // 入力チェック <HTML側に処理を移動>
/*
  if (isNumber(parseFloat(document.form3.elements[1].value)) == false 
  ||  isNumber(parseFloat(document.form3.elements[2].value)) == false
  ||  isNumber(parseFloat(document.form3.elements[3].value)) == false) {
    alert("数値以外の文字が含まれています");
    return;
  }
*/
  // フォーム入力項目の取得
  var v_H2 = parseFloat(document.form3.elements[1].value);
  var v_Bl2 = parseFloat(document.form3.elements[2].value);
  var v_Br2 = parseFloat(document.form3.elements[3].value);

  // tan Bl
  var v_tan_Bl3 = v_Bl2 / v_H2;
  target = document.getElementById("id_tan_Bl3");
  target.value = v_tan_Bl3;
  // tan Br
  var v_tan_Br3 = v_Br2 / v_H2;
  target = document.getElementById("id_tan_Br3");
  target.value = v_tan_Br3;
  // Bl
  var v_Bl3 = Math.atan(v_tan_Bl3) * 180 / Math.PI;
  target = document.getElementById("id_Bl3");
  target.value = v_Bl3;
  // Br
  var v_Br3 = Math.atan(v_tan_Br3) * 180 / Math.PI;
  target = document.getElementById("id_Br3");
  target.value = v_Br3;
}
//------------------------------------------------
// 最大安定傾斜角度の計算
//------------------------------------------------
function onButton4Click() {

  // 入力チェック <HTML側に処理を移動>
/*
  if (isNumber(parseFloat(document.form4.elements[3].value)) == false 
  ||  isNumber(parseFloat(document.form4.elements[4].value)) == false
  ||  isNumber(parseFloat(document.form4.elements[5].value)) == false
  ||  isNumber(parseFloat(document.form4.elements[6].value)) == false) {
    alert("数値以外の文字が含まれています");
    return;
  }
*/
  // フォーム入力項目の取得
  var v_Bl_3 = parseFloat(document.form4.elements[3].value);
  var v_Br_3 = parseFloat(document.form4.elements[4].value);
  var v_w3 = parseFloat(document.form4.elements[5].value);
  var v_W3 = parseFloat(document.form4.elements[6].value);

  // 計算処理
  var devide =  v_W3 / v_w3;
  target = document.getElementById("id_Ww");
  target.value = devide;

  var border = 0;
  if(devide > 1.2) {
    border = 35;
  }
  else {
    border = 30;
  }
  target = document.getElementById("id_judge");
  target.value = border;

  if(v_Bl_3 >= border && v_Br_3 >= border) {
    target = document.getElementById("id_result");
    target.innerHTML = "<img src =\"./images/ok.jpg\">"
  }
  else {
    target = document.getElementById("id_result");
    target.innerHTML = "<img src =\"./images/ng.jpg\">"
  }
}
//------------------------------------------------
// 数値チェック処理
//------------------------------------------------
function isNumber(numVal){
  // チェック条件パターン
  var pattern = /^[-]?([1-9]\d*|0)(\.\d+)?$/;
  // 数値チェック
  return pattern.test(numVal);
}
